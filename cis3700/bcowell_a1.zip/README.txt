Brayden Cowell
0844864
CIS*3700 A1
README.txt
----------------------

New to Java so this assignment was very challenging. Seemed strange not do something like this in c.
In the end I managed to get the SearchAgent to solve the puzzles but could figure out how to properly format the solution.

TO USE
-----------------
Compile everything
$ make all

Run a test
$ make run

Cleanup
$ make clean